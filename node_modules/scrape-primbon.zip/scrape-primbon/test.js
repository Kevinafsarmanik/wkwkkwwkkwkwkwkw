const Primbon = require('./index')
const primbon = new Primbon()

primbon.arti_nama('Dika').then((res) => {
    console.log(res)
})
