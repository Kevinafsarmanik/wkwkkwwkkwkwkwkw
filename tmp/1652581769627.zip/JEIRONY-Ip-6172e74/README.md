## Bienvenido a IP Dox

Este es un script creado para el doxeo, a travéz de una petición web logra acortar el link original a camuflar por uno especial, este link se copia automaticamente
en la clipboar. Su funcion es que el usuario pase por un enlace intermediario que lo reedireciona al enlace principal, en esta reedireción se likea
información importante sombre el usuario. Tambien se puede utilizar el script [evil link](https://github.com/Alcatraz2033/evil-link) para camuflar el enlace a uno mucho
más convincente. Esto solo demuestra lo peligroso que puede llegar a ser un simple enlace web.

<p align="left">
	<img src="https://i.imgur.com/CXRWeJM.png" width="75%" height="75%" align="">
</p>

## Instalación

Clonar el repositorio y cambiar los permisos

```markdown
git clone https://github.com/Alcatraz2033/IP-Dox.git
cd IP-Dox
chmod +x ip_doxx.sh
sudo ./ip_doxx.sh
```
