let handler = (t) => {
t.reply('*https://github.com/BrunoSobrino/TheMystic-Bot-MD*')
}
handler.command = ['sc','script']
handler.help = ['sc']
handler.tags = ['General']
export default handler
